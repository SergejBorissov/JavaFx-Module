package com.example.javafxcallbacks;

import javafx.beans.property.SimpleStringProperty;
import javafx.beans.property.StringProperty;

public class Person 
{

    private StringProperty name;
    private StringProperty lastName;

    public Person(String name, String lastName){
        this.name = new SimpleStringProperty(name);
        this.lastName = new SimpleStringProperty(lastName);
    }



    public StringProperty nameProperty(){
        return name;
    }
    public StringProperty lastNameProperty(){
        return lastName;
    }
    public String getName(){
        return name.get();
    }
    public String getLastName(){
        return lastName.get();
    }
    public void setName(String name){
        this.name.set(name);
    }
    public void setLastName(String lastName){
        this.lastName.set(lastName);
    }
}
