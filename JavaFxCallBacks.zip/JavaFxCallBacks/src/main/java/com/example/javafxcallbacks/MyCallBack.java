package com.example.javafxcallbacks;

import javafx.beans.value.ObservableValue;
import javafx.scene.control.TableColumn;
import javafx.util.Callback;

public class MyCallBack implements Callback<TableColumn.CellDataFeatures<Person, String>, ObservableValue<String>>{

    @Override
    public ObservableValue<String> call(TableColumn.CellDataFeatures<Person, String> param) {
        return param.getValue().nameProperty();
    }
}