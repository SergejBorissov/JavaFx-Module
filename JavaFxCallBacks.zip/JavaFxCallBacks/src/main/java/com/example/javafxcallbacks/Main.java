package com.example.javafxcallbacks;

import javafx.application.Application;
import javafx.fxml.FXMLLoader;
import javafx.scene.Scene;
import javafx.scene.control.TableColumn;
import javafx.scene.control.TableView;
import javafx.stage.Stage;

import java.io.IOException;

public class Main extends Application {
    @Override
    public void start(Stage stage) throws IOException {
        stage.setTitle("Callback ");
        TableView<Person> table = new TableView<Person>();
        table.getItems().add(new Person("Euler", "Leon"));
        table.getItems().add(new Person("Fred", "Gauß"));

        TableColumn<Person, String> firstNameColumn = new TableColumn<>("Vorname");
        firstNameColumn.setCellValueFactory(new MyCallBack());

        TableColumn<Person, String> lastNameColumn = new TableColumn<>("Nachname");

        table.getColumns().add(firstNameColumn);
        table.getColumns().add(lastNameColumn);

        stage.setScene(new Scene(table));
        stage.show();


       // FXMLLoader fxmlLoader = new FXMLLoader(Main.class.getResource("hello-view.fxml"));
        //Scene scene = new Scene(fxmlLoader.load(), 320, 240);

    }

    public String myFunction(Object o)
    {
        return o.toString();
    }

    public static void main(String[] args) {
        launch();
    }
}