module com.example.javafxcallbacks {
    requires javafx.controls;
    requires javafx.fxml;


    opens com.example.javafxcallbacks to javafx.fxml;
    exports com.example.javafxcallbacks;
}